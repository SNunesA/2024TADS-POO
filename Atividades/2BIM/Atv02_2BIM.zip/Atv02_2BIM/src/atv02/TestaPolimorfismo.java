package atv02;

public class TestaPolimorfismo {

	public static void main(String[] args) {
		
		if (args[0].equals("Tempo")) {
			Tempo obj = new Tempo();
		}
		if (args[0].equals("Horario")) {
			Horario obj = new Horario(Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3]));
		}	
		if (args[0].equals("Data")) {
			Data obj = new Data(Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3]));
		}
		if(args.length != 4) {
			System.out.println("Formato esperado:Tipo inteiro inteiro inteiro");
		}
		if (! args[0].equals("Data") & ! args[0].equals("Horario") & ! args[0].equals("Tempo")) {
			System.out.println("Tipo inexistente");
		}
	}
}
