package atv02;

public class Tempo {

	public int quantidade() {
		return 0;
	}
	public String toString() {
		return null;
	}
}
