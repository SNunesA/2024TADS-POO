package Atv01;

public class TestaBrinquedo {

	public static void main(String[] args) {
		Brinquedo A = new Brinquedo();
		Brinquedo B = new Brinquedo("Boneca");
		Brinquedo C = new Brinquedo("Caminhão",19.90f);
		
		A.mostrar();
		B.mostrar();
		C.mostrar();
		
		A.setNome("Castelo");
		System.out.println("\nNome do brinquedo A:"+A.getNome()); 
		A.setPreco(40.25f);
		
		B.setPreco(10.50f);
		System.out.println("Preço do brinquedo B:"+B.getPreco());
		
		C.setFaixaEtaria("6 a 10");
		C.setFaixaEtaria("3 a 4");
		System.out.println("Faixa etaria do brinquedo C:"+C.getFaixaEtaria());
		A.setFaixaEtaria("acima de 10");
		B.setFaixaEtaria("3 a 5");
		System.out.println("\n");
		
		A.mostrar();
		B.mostrar();
		C.mostrar();
	}

}
