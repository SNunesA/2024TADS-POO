package Atv01;

public class Brinquedo {
	private String nome;
	private String faixaetaria;
	private float preco;
	
	public Brinquedo() {}
	public Brinquedo(String nome) {
		this.nome=nome;
	}
	public Brinquedo(String nome, float preco) {
		this.nome=nome;
		this.preco=preco;
	}
	
	public void mostrar() {
		System.out.println("Nome:"+nome+" Faixa Etaria:"+faixaetaria+" Preço:"+preco);
	}
	
	public void setNome(String nome) {
		this.nome=nome;
	}
	public String getNome() {
		return nome;
	}	
	
	public void setFaixaEtaria(String faixa) {
		if(faixa == "0 a 2" || faixa == "3 a 5" || faixa == "6 a 10" || faixa == "acima de 10") {
			this.faixaetaria=faixa;
		}
	}
	public String getFaixaEtaria() {
		return faixaetaria;
	}	
	
	public void setPreco(float preco) {
		this.preco=preco;
	}
	public float getPreco() {
		return preco;
	}	
}
 